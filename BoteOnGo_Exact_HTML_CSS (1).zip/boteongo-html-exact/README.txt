BoteOnGo - HTML + CSS + JS build. Open index.html (double-click) or upload this folder to Netlify.
Sign in: "Direct sign in (demo account)" or Register.
Demo account: 0917 555 1122 / Maria@1234     Admin password: Admin@1234
Password rule for new accounts: 8+ characters, 1 lowercase, 1 uppercase, 1 special.
Junk shop prices are edited by the Admin only (Admin > Shop Prices).
Live sync between devices needs Firebase: see SYNC_SETUP.txt in the project zip.
